# yoman-system — ייצוא זיכרון, סקילים ופלאגינים

- `memory/project/` — זיכרון הפרויקט "מערכת יומן" (7 קבצים)
- `memory/account/` — זיכרון כללי של יובל (13 קבצים)
- `skills/` — 21 סקילים שיובל בנה (בלי סקילי Anthropic)
- `plugins/` — netanel-gen, yachin-gen, betzalel-gen

מסמכי הפרויקט (00–16, data/, אפיון) הועברו בנפרד.
