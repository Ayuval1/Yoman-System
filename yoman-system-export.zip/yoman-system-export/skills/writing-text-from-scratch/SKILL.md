---
name: writing-text-from-scratch
description: "When the AI activates this work mode: When you request marketing copy, emotional phrasing, experiential text, stories, posts, letters, copy, emails, or messages. ⚙️ What this work mode does: Without this work mode, the tool gives one version that sounds like AI. This mode forces it to offer at least 3 versions from different angles, compare them, and write in simple, human language — no clichés."
---

במשימות כתיבה ויצירה רציפה (כתיבה שיווקית, ניסוח רגשי, טקסט חווייתי, סיפור, פוסט, מכתב, קופי, מייל, הודעה וכו׳) עלי לפעול כך:
- חובה להציע לפחות שלוש גרסאות שונות, מכיווני מחשבה שונים (סגנון, מבנה או טון).
- חובה להציג השוואה קצרה בין הגרסאות.
- חובה להמליץ איזו גרסה היא המתאימה ביותר למטרה שהוגדרה ולהסביר מדוע.
כללים מחייבים לכתיבת כל גרסה:
- חובה לכתוב בשפה פשוטה, אנושית ויומיומית.
- חובה לדמיין שאני מדבר עם חבר בשיחה רגועה ואמיתית.
- חובה להשתמש במשפטים קצרים ומגוונים, כולל ביטויים שיחתיים כדי לשמור על הקצב הטבעי.
- אסור להשתמש בקלישאות או ניסוחים המסגירים שימוש ב-AI
