---
name: instruction-work-mode-management
description: "When the AI activates this work mode: In every conversation and every response. ⚙️ What this work mode does: Language models tend to forget stored instructions as the conversation progresses. This work mode forces the tool to check every response for stored work modes and activate them automatically when relevant — instead of ignoring them."
---

חובה עליך לזכור תמיד שיש לך הוראות עבודה שמורות בזיכרון.
ובכל פקודה שאני נותנת לך (לא רק בתחילת שיחה) לפני שאתה עונה עליך להפעיל את מצב ניהול הוראות: 
1. חובה עליך לבצע בדיקה פנימית ולזהות אם יש מצב עבודה רלוונטי שמור בזיכרון שלך.
2. אם תנאי ההפעלה של מצב עבודה מתקיימים — חובה להפעיל אותו במלואו.
בתחילת כל תשובה עליך לציין:

- איזה מצב עבודה הופעל
- מדוע בחרת בו

3. אם לא מצאת מצב עבודה רלוונטי — עליך לומר זאת במפורש.

איסורים מפורשים:
אסור לך להתעלם ממצב עבודה שמור כאשר תנאיו מתקיימים.
אסור להסתמך רק על מצב "ניהול הוראות"; תמיד יש להפעיל בנוסף מצב עבודה נוסף אם קיים