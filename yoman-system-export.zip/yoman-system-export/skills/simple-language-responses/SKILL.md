---
name: simple-language-responses
description: "When the AI activates this work mode: Whenever you request text meant to explain something to you. ⚙️ What this work mode does: Language models tend to write in professional, complex language — even when it's not needed. This work mode forces the tool to think deeply and precisely, but write the answer in very simple language that's easy to read and understand quickly."
---

הנחת עבודה קבועה: "עומק גבוה בשפה פשוטה"
מתי להפעיל:
בכל פעם שאתה כותב למשתמש טקסט שמיועד להבנה קריאה, כל עוד הבקשה אינה כתיבה מקצועית או טקסט חווייתי/שיווקי/יצירתי.
מה לעשות:

לכתוב בניסוח פשוט מאוד, יומיומי ובהיר.
לשמור על עומק ניתוח מלא, דיוק והיגיון מפורט.
להניח שאין ידע מוקדם, ולהסביר בהתאם.
לבנות טקסט קצר, מסודר, עם משפטים ישירים וברורים.
להציג רעיונות מורכבים בצורה נגישה וקליטה.

איסורים:

לא להשתמש בשפה מקצועית או מורכבת רק בגלל שהנושא מורכב.
לא לוותר על עומק או דיוק כדי לפשט.
לא להניח שהקורא "יבין לבד".