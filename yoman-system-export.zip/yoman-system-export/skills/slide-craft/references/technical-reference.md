# reference טכני — בניית שקף HTML

הקובץ הזה הוא מקור האמת לכל מה שקורה בתוך קובץ ה-HTML של שקף. קרא אותו לפני שכותבים.

## הקנבס

כל שקף הוא קובץ HTML עצמאי אחד עם **aspect-ratio של 16/10**. הבסיס לחישוב הוא קנבס לוגי של **1280 × 800** — עצב כאילו רוחב השקף הוא 1280 וגובהו 800. הדפדפן מקנה את זה לגודל החלון תוך שמירת היחס.

- עטוף את השקף ב-`.slide` עם `aspect-ratio:16/10; width:100%; max-width:1040px;`.
- אפשר להשתמש ב-`clamp()` לגדלים כדי שהטקסט יגדל עם השקף — **אבל בחר סולם עקבי** ואל תמציא ערכים אקראיים לכל שקף.
- שורש כל שקף ממלא את הקנבס: `width:100%; height:100%`.

## Type scale (התחל כאן, כוונן לטעם)

הגדרות ביחס לקנבס 1280×800. אם משתמשים ב-`clamp`, השתמש באמצע כערך הבסיס:

| אלמנט            | גודל       |
| ---------------- | ---------- |
| כותרת־על (hero)  | 96–140px   |
| כותרת פרק        | 56–84px    |
| כותרת שקף        | 40–56px    |
| טקסט body        | 22–30px    |
| כיתוב / תווית    | 15–19px    |

## מרווחים

- **padding מהקצוות: 52–80px.** לעולם אל תיתן לטקסט לגעת בקצה.
- **line-height:** 1.05–1.15 לכותרות, 1.5–1.7 ל-body.
- **אוויר בין אלמנטים:** 20–44px.
- בחר padding אחד לכל השקפים והיצמד אליו.

## תקציב אנכי — התוכן חייב להיכנס ב-800px

הקנבס **לא גולל**. כל מה שעובר את גובה 800 נחתך בשקט. לפני שכותבים JSX/HTML, עשה את החשבון וודא שהשקף נכנס. זו הסיבה מספר 1 לשקפים שבורים.

**גובה שמיש** = `800 − padding_עליון − padding_תחתון`. עם padding של 64px מכל צד → **672px**. עם 80px → **640px**. בחר padding קודם, ואז עצב בתוך התקציב.

**גובה אלמנט** = `font_size × line_height × מספר_שורות`. נקודה שנשברת לשתי שורות נספרת כשתיים. הוסף את הרווח מתחתיה לפני שמסכמים את הבא.

**דוגמה — שקף תוכן יחיד, padding 64px (תקציב 672px):**

| אלמנט                                | גובה                    |
| ------------------------------------ | ----------------------- |
| כותרת: 56px × 1.1 × שורה             | 62px                    |
| רווח                                 | 40px                    |
| פסקת body: 28px × 1.6 × 3 שורות      | 134px                   |
| רווח                                 | 32px                    |
| 4 נקודות: 26px × 1.6 × שורה כל אחת   | 166px                   |
| 3 רווחים בין נקודות: 20px            | 60px                    |
| **סה"כ**                             | **494px ✅ נכנס ב-672**  |

**כללי שקף:**
- כותרת + body **או** כותרת + ≤5 נקודות קצרות. לא גם פסקאות body וגם רשימה ארוכה.
- נקודה צריכה להיכנס בשורה אחת בגודל הפונט הנבחר. אם היא נשברת — קצר, או העבר לשקף משלה.
- שקפי כותרת־על (96–140px) נושאים כותרת + תת־כותרת אחת + אולי eyebrow — כלום מעבר.
- אם אתה מגלה שאתה מעלה padding, מכווץ פונט מתחת לסולם, או מהדק line-height מתחת ל-1.4 כדי שזה ייכנס — **פצל לשני שקפים במקום.** פיצול הוא כמעט תמיד התשובה הנכונה.

**לעולם אל** תשתמש ב-`overflow:auto/scroll`, margin שלילי, או transform כדי להסתיר עודף. הקנבס קבוע; תוכן חתוך אבד.

## כיוון ויזואלי

בחר מראה קוהרנטי אחד והחזק אותו לרוחב כל שקף:
- **פלטה** — רקע אחד, טקסט ראשי אחד, אקסנט אחד, מיושתק אחד. שים אותם ב-`:root` כמשתני CSS.
- **טיפוגרפיה** — פונט display אחד + פונט body אחד. משקל כבד לכותרות (800–900), רגיל ל-body.
- **גריד** — בחר padding אחד (למשל 64px) והיצמד. שמאל־מיושר = עריכתי; ממורכז = טקסי.
- **התחייבות אסתטית** — בחר אחת: מינימלי / מקסימלי / עריכתי / רטרו / ברוטליסטי / רך / ניאון / נייר. אל תערבב.

## עברית ו-RTL

- `<html lang="he" dir="rtl">`.
- למספרים ואנגלית בתוך טקסט עברי, עטוף ב-`direction:ltr; unicode-bidi:isolate` כדי שלא יתהפכו.
- פונטים עבריים כבדים טובים לכותרות: Rubik 900, Heebo 900, Assistant. הימנע מ-Secular One אם המשתמש לא ביקש.
- ל-Google Fonts השתמש ב-`@import` בראש ה-`<style>`.

## תבנית התחלה (16:10, RTL)

```html
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>שקופית</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Heebo:wght@400;700;900&family=Rubik:wght@400;700;900&display=swap');

  :root{
    /* פלטה — החלף לפי השפה העיצובית שחולצה/נבחרה */
    --bg:#141414;
    --text:#FFFFFF;
    --accent:#FF5A1F;
    --muted:#8A8A8A;
    /* טיפוגרפיה */
    --font-display:'Rubik',sans-serif;
    --font-body:'Heebo',sans-serif;
  }
  *{box-sizing:border-box;margin:0;padding:0;}
  html,body{height:100%;background:#050403;font-family:var(--font-body);-webkit-font-smoothing:antialiased;}
  body{display:flex;align-items:center;justify-content:center;padding:28px;}

  .slide{
    position:relative;
    width:100%;
    max-width:1040px;
    aspect-ratio:16/10;
    background:var(--bg);
    color:var(--text);
    border-radius:18px;
    overflow:hidden;
    padding:64px 72px;
    display:flex;
    flex-direction:column;
    justify-content:center;
  }

  .eyebrow{
    font-family:var(--font-body);font-weight:700;font-size:16px;
    letter-spacing:.12em;text-transform:uppercase;color:var(--accent);
    margin-bottom:20px;
  }
  .title{
    font-family:var(--font-display);font-weight:900;line-height:1.08;
    font-size:clamp(40px,5.4vw,64px);letter-spacing:-.02em;
  }
  .lead{
    font-family:var(--font-body);font-size:clamp(18px,1.9vw,26px);
    line-height:1.6;color:var(--muted);max-width:52ch;margin-top:24px;
  }
</style>
</head>
<body>
  <div class="slide">
    <div class="eyebrow">פרק 01</div>
    <h1 class="title">הרעיון הגדול</h1>
    <p class="lead">תת־כותרת קצרה שמסבירה על מה השקף הזה.</p>
  </div>
</body>
</html>
```

## אלמנטים חוזרים

כשיש אלמנטים ויזואליים חוזרים (כרטיסים, שורות לוגו, אריחים) — הגדר class אחד וחזור עליו. שמור על אחידות: אותו class, אותם מרווחים, אותה טיפוגרפיה. השתנות רק בתוכן.

## סקירה עצמית לפני סיום

- [ ] השקף ב-aspect-ratio 16/10, שורש ממלא 100%×100%.
- [ ] התוכן בתוך ה-padding — שום טקסט לא נוגע בקצה.
- [ ] **סכום (font_size × line_height × שורות) + רווחים + 2×padding ≤ 800px.** אם קרוב — פצל.
- [ ] שום נקודה לא נשברת לשורה שנייה בגודל הנבחר.
- [ ] כיוון ויזואלי אחד קוהרנטי לרוחב כל שקף (פלטה + type scale).
- [ ] מוקד ויזואלי אחד לשקף.
- [ ] ציר יישור אחד — לא חלק ממורכז וחלק צמוד לקצה.
- [ ] פלטה וטיפוגרפיה ב-`:root`, בשימוש עקבי דרך `var(--X)`.
- [ ] מספרים/אנגלית בתוך עברית עטופים ב-`direction:ltr;unicode-bidi:isolate`.
- [ ] טקסט body ≥ 22px יחסי.
