---
name: extract-principles-for-new-chat
description: Extract the reusable principles, workflows, constraints, preferences, lessons, formulas, and decision rules from the current conversation and turn them into a self-contained SKILL.md-style prompt that can be reused in a new chat. Use when the user asks to "חלץ את כל העקרונות לשיחה חדשה" or equivalent wording such as "extract all the principles for a new conversation" — and also when the user asks for a prompt/handoff to continue an unfinished task in the next session (e.g. "כתוב לי פרומפט להמשיך בשיחה הבאה", "give me a prompt to continue next time", "prep a handoff for tomorrow"). In that second case the output leads with a concrete Session Handoff block, not just generalized method. Do not merely summarize; generalize the underlying method and preserve important practical details.
---

# Extract Principles for a New Chat

## Purpose

Turn the current conversation into a reusable, self-contained instruction set that can be pasted into a new conversation or saved as another skill.

The goal is to preserve the **way of working**, not merely the conversation's content.

## Trigger

Activate when the user asks for any equivalent of:

- "חלץ את כל העקרונות לשיחה חדשה"
- "חלץ את העקרונות לשיחה חדשה"
- "תוציא את כל העקרונות לשיחה חדשה"
- "extract all the principles for a new chat"
- "turn this conversation into a reusable prompt/skill"

Also activate — as the **handoff variant** described below — when the user asks for any equivalent of:

- "כתוב לי פרומפט להמשיך בשיחה הבאה"
- "תכין לי המשך לסשן הבא"
- "give me a prompt to continue next session"
- "prep a handoff for tomorrow / next chat"

These two triggers point at the same underlying need — a fresh conversation should be able to pick up without re-reading this one — but they weight the output differently. A request to "extract principles" is about the **reusable method**: it should work even for a *different* future task in the same domain. A request to "continue" or "hand off" is about **this specific unfinished task**: what's the state, what's already decided, what's the next concrete step. Most real handoff requests want both — resume exactly where things stand, *and* not repeat mistakes/patterns from this session — so default to producing both parts rather than picking one.

## Core Rule

Do not produce a conventional summary.

Instead, identify and generalize:

1. Reusable principles
2. Working methodology
3. Step-by-step workflows
4. Decision rules
5. Constraints and requirements
6. User preferences that materially affect future answers
7. Formulas, calculations, or technical rules
8. Important edge cases
9. What worked and what did not work
10. Corrections made during the conversation
11. Assumptions that should or should not be made
12. Output-format expectations

The resulting artifact must allow a fresh conversation to behave as if it understands the established working method, without needing the original conversation.

## Extraction Process

### 1. Identify the real task

Determine what the conversation was actually trying to accomplish, beyond individual questions.

Example:
- Surface task: calculate a pizza dough recipe.
- Underlying reusable method: scale recipes accurately to a target dough-ball weight while preserving baker's percentages and accounting for fermentation conditions.

### 2. Separate facts from principles

Do not blindly copy every fact.

Classify information into:

- **Reusable principle** — should be preserved.
- **Workflow** — should be preserved.
- **Constraint** — should be preserved if it applies generally.
- **Preference** — preserve if it affects future responses.
- **One-off fact** — include only if necessary to understand the method.
- **Temporary detail** — normally omit.

### 3. Generalize the method

Convert specific examples into rules.

For example:

> "The user wanted one 280 g pizza ball."

becomes:

> "When scaling a dough recipe, calculate the scaling factor from the original total dough weight to the requested target weight, then multiply every ingredient by that factor and verify the final sum."

### 4. Preserve useful formulas

Whenever the conversation contains calculations, preserve the exact reusable formulas.

For example:

- Total dough weight = sum of all ingredients.
- Original ball weight = total dough weight ÷ number of balls.
- Scaling factor = target ball weight ÷ original ball weight.
- New ingredient quantity = original ingredient quantity × scaling factor.
- Final verification = sum of scaled ingredients ≈ target weight.

### 5. Capture corrections

If the conversation contains a mistake followed by a correction, preserve the corrected rule and, when useful, explicitly state the failure mode so it is not repeated.

Example:

> Do not calculate a scaled ingredient directly from an incorrect intermediate ratio. First calculate total dough weight and original ball weight, then derive the scaling factor.

### 6. Capture edge cases

Include practical cases that materially change the workflow.

For example:

- Summer vs. winter temperatures
- Short vs. long fermentation
- Refrigerator vs. room-temperature fermentation
- Ingredients contained inside preferments/starter
- Small quantities that are difficult to weigh accurately
- A target preparation time that occurs later than the dough's natural readiness

### 7. Capture output expectations

Extract how the user wants future answers structured.

Examples:

- Direct answer first
- Clear final numbers
- Minimal unnecessary explanation for simple calculations
- Full schedule when timing is involved
- Explicit verification of calculations

## Required Output Structure

Return a copy-ready artifact with a clear title and sections such as:

# [Topic / Working System] — Reusable Skill

## Session Handoff *(include this block whenever the conversation has an unfinished, concrete task — not only when the user used handoff wording explicitly)*

A short, literal, paste-into-next-chat prompt. Not generalized — this is state, not method:

- What the task is, in one line.
- What's already locked/decided and must not be re-litigated (with file paths or exact references if any exist).
- What's still open.
- The single next concrete step.
- Which files/context to (re)load before starting, if applicable.

Format it as a fenced block the user can copy verbatim. Keep it short enough to paste as the first message of a new chat — this is not the place to restate the full methodology below; it points at state, the rest of the document explains the method.

## Purpose

## Context

Only include durable context that materially affects future work.

## Core Principles

Numbered, generalized rules.

## Workflow

A step-by-step procedure for future tasks.

## Formulas / Technical Rules

Exact formulas and calculation rules.

## Decision Rules

If/then logic and practical choices.

## Edge Cases

Important exceptions and failure modes.

## What to Avoid

Known mistakes, bad assumptions, and approaches that failed.

## Output Format

How future answers should be presented.

## Example

Include one compact example only when it makes the reusable method clearer.

## Quality-Control Checklist

A short checklist the assistant can use before finalizing future answers.

## Quality Standard

The extracted skill should be:

- Self-contained
- Reusable
- Generalized rather than transcript-like
- Specific enough to change future behavior
- Free of unnecessary one-off conversation details
- Faithful to the established method
- Easy to paste into a new chat
- Suitable for conversion into a Claude Code skill
- Leads with a concrete Session Handoff block when the underlying task is still unfinished, not just the generalized method

## Important Distinction

If the user asks for this extraction, do not answer with:

> "Here is a summary of our conversation."

Instead answer with something equivalent to:

> "Here is the reusable skill extracted from the conversation."

The artifact should describe **how to solve future versions of the problem**, not just what happened this time.

## When Creating a Claude Skill File

If the user explicitly asks to turn the extracted principles into a Claude skill, create:

```text
<skill-name>/
└── SKILL.md
```

The `SKILL.md` should contain:

1. YAML frontmatter with `name` and `description`.
2. Clear activation/use conditions.
3. Operational instructions.
4. Workflows and decision rules.
5. Quality-control rules.

If the user asks for a ZIP, package the skill directory as:

```text
<skill-name>.zip
```

The ZIP should contain the directory and its `SKILL.md`, for example:

```text
extract-principles-for-new-chat.zip
└── extract-principles-for-new-chat/
    └── SKILL.md
```

Do not include unrelated files.
