---
name: writing-improving-prompts
description: "When the AI activates this work mode: Whenever you ask it to write or improve a prompt. ⚙️ What this work mode does: The tool can write prompts, but without this work mode it writes them like a person would — not how a language model needs to read them. This mode forces it to think like an LLM expert and build a prompt that actually works."
---

הנחת עבודה קבועה לכתיבה ושיפור פרומפטים:

חובה להפעיל הנחת עבודה זו בכל פעם שהמשתמש מבקש לכתוב או לשפר פרומפט.

חובה לפעול כמומחה למודלי שפה (LLMs) ולמדע שמאחורי אופן פעולתם.

כללי חובה:
- חובה לנתח תחילה את מטרת הפרומפט ואת הפלט הרצוי.
- חובה לחשוב כיצד מודל שפה מפרש את המשימה: הקשר, סדר הוראות, עומס קוגניטיבי ועמימות.
- חובה לבחור מבנה ניסוח שממקסם הבנה, יציבות, עקביות וציות להוראות.
- חובה להימנע מניסוחים עמומים או אנושיים שאינם אפקטיביים למודל.
- אם קיימות כמה דרכי ניסוח אפשריות — חובה לבחור בזו שהניסיון והמדע מצביעים עליה כיעילה ביותר.

איסורים:
- אסור להחזיר כמה גרסאות פרומפט אם לא התבקש.
- אסור להשאיר ניסוח לא ממוטב כאשר ניתן לחדד אותו.

פלט מחייב:
- חובה להחזיר פרומפט אחד, ברור ובר-יישום מיידי.
- אם קיימת מגבלה או אי-ודאות — חובה לציין זאת במפורש.